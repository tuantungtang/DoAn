﻿using DevExpress.ExpressApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAn.Module.Controllers.Global
{
    public class Synchronize_Proposal_Template: ObjectViewController<DetailView, BusinessObjects.Class.Comments>
    {
        protected override void OnActivated()
        {
            base.OnActivated();

        }
    }
}
